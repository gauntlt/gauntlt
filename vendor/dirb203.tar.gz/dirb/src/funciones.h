/*
 * DIRB
 *
 * funciones.h - Global Functions
 *
 */

#include "global.h"


/* Funciones */

void banner(void);
void ayuda(void);

struct result get_url(char *resp_url);
size_t get_header(void *ptr, size_t size, size_t nmemb, void *stream);
size_t get_body(void *ptr, size_t size, size_t nmemb, void *stream);

void lanza_ataque(char *url_base, struct words *wordlist);

void get_options(void);

int get_necs(char *direccion);
struct result *calcula_nec(char *direccion);


struct words *crea_wordlist(char *ficheros);
struct words *crea_wordlist_fich(char *fichero);
struct words *crea_extslist(char *lista);

FILE *abrir_file(char *file);
void check_url(char *url);
void limpia_url(char *limpia);
void barra(char *barr);
void guardadir(char *direccion);
void elimina_dupwords(struct words *puntero);
int location_cmp(char *A, char *B);
void location_clean(char *cleaned, char *toelim);
int islistable(char *direccion);
char kbhit(void);
char *code2string(struct code *a, u_int v);
void init_exts(void);
void cierre(void);
char *uri_decode(char *uri);

void dump(void);
void resume(void);


