/*
 * DIRB
 *
 * global.h - Global Includes
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <termios.h>
#include <sys/stat.h>
#include <sys/errno.h>
#include <curl/curl.h>
#include "../config.h"


/* Constantes */

#define MAX_FAILS   	5
#define TIMEOUT     	40
#define BIGWORDLIST   	20000
#define AGENT_STRING  	"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)"
#define MAX_ALERT   	100
#define STRING_SIZE   	256
#define DUMP_TIMEOUT  	100

#define DUMP_DIR    	"resume"
#define OPTIONS_DUMP  	"resume/options.dump"
#define WORDLIST_DUMP 	"resume/wordlist.dump"
#define DIRLIST_DUMP  	"resume/dirlist.dump"
